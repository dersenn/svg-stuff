import Session from './browser-opentypejs.js';

window.SvgTextToPath = Session;