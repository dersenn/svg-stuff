import Session from './browser-fontkit.js';

window.SvgTextToPath = Session;
